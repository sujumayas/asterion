A Pen created at CodePen.io. You can find this one at http://codepen.io/Xinefio/pen/VpYNvN.

 Trails of particles started in circles into canvas. The  canvas is not clean for build trails.