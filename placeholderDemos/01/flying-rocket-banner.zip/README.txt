A Pen created at CodePen.io. You can find this one at http://codepen.io/Xinefio/pen/YZPMPM.

 Animated rocketship page banner. Rocketships are cool.