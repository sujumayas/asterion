A Pen created at CodePen.io. You can find this one at http://codepen.io/Xinefio/pen/BWyENo.

 inspired by http://codepen.io/jscottsmith/pen/KrJvAq