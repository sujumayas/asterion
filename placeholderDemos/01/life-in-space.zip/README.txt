A Pen created at CodePen.io. You can find this one at http://codepen.io/Xinefio/pen/mWyoYZ.

 Animated space background.
Life in space!

#apsolut